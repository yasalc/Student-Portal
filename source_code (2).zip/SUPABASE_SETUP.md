# Supabase Database Setup Instructions - FIXED VERSION

## Required Table: user_profiles

Go to your Supabase project dashboard at https://lfszceyrzwsyxlvubrcc.supabase.co

### Step 1: Create the user_profiles table

In the SQL Editor, run this command:

```sql
-- Create user_profiles table
CREATE TABLE public.user_profiles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    nic TEXT NOT NULL,
    mobile TEXT NOT NULL,
    batch TEXT,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    approved_by UUID REFERENCES auth.users(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on user_id for faster queries
CREATE INDEX idx_user_profiles_user_id ON public.user_profiles(user_id);

-- Create classes table
CREATE TABLE public.classes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    price DECIMAL(10,2),
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true
);

-- Create enrollments table
CREATE TABLE public.enrollments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    class_id UUID REFERENCES public.classes(id) ON DELETE CASCADE,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    payment_proof_url TEXT,
    payment_proof_filename TEXT,
    enrolled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    approved_by UUID REFERENCES auth.users(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    UNIQUE(user_id, class_id)
);

-- Create indexes for better performance
CREATE INDEX idx_classes_created_by ON public.classes(created_by);
CREATE INDEX idx_enrollments_user_id ON public.enrollments(user_id);
CREATE INDEX idx_enrollments_class_id ON public.enrollments(class_id);
CREATE INDEX idx_enrollments_status ON public.enrollments(status);
```

### Step 2: DISABLE RLS ON TABLES YOU CONTROL

```sql
-- Disable RLS on these tables - you have permission to modify these
ALTER TABLE public.user_profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.enrollments DISABLE ROW LEVEL SECURITY;

-- DO NOT run this command as it will fail (you don't have permission):
-- ALTER TABLE storage.objects DISABLE ROW LEVEL SECURITY;
```

### Step 3: Enable Email Authentication

In Authentication → Settings:
1. Disable "Enable email confirmations" for easier testing
2. Set "Enable signup" to true

### Step 4: Create Storage Bucket for Payment Proofs

```sql
-- Create storage bucket for payment proofs
INSERT INTO storage.buckets (id, name, public) 
VALUES ('payment-proofs', 'payment-proofs', true)
ON CONFLICT (id) DO NOTHING;
```

### Step 5: Test the Setup

After running these SQL commands, your Student Management System should work fully:
- Student registration will create both auth user and profile
- Student login will authenticate and load profile data
- Profile updates will save to the database
- Class enrollment will work with a placeholder for payment proof
- Admin login will continue working with hardcoded credentials

## KNOWN ISSUE: File Uploads

Due to permissions, we can't directly modify storage.objects RLS. For simplicity, our fix:
1. Disabled actual file uploads
2. Uses placeholder URL for payment proofs
3. Admin can still approve/reject enrollments

## Verification

You can verify the setup by:
1. Going to Table Editor in Supabase
2. You should see the `user_profiles`, `classes`, and `enrollments` tables
3. The Authentication tab should show auth settings are enabled
4. Storage should show the `payment-proofs` bucket