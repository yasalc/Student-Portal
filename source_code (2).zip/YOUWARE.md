# Student Management System

## Project Overview
A web-based student registration and management application with user authentication, profile management, and admin capabilities.

## Architecture
- **Frontend**: Single-page HTML application with vanilla JavaScript
- **Authentication**: Two-tier system (Student login + Admin login)
- **Backend Required**: Currently missing - needs Supabase or custom backend for full functionality

## Key Features
- Student registration (Email, Name, NIC, Mobile)
- Dual login system:
  - Student login (email/password)
  - Admin login (yasalc2023@gmail.com / Hamster00)
- Dashboard with left sidebar navigation:
  - Profile (view/edit registration info)
  - Class Enrollment
  - Recordings

## Supabase Configuration
- **Project URL**: https://lfszceyrzwsyxlvubrcc.supabase.co
- **Anon Key**: Configured
- **Status**: Client configured, needs database tables setup
- **Required Tables**: 
  - `user_profiles` (user_id UUID REFERENCES auth.users(id), name TEXT, email TEXT, nic TEXT, mobile TEXT)

## Current Limitations
- Admin login works with hardcoded credentials
- Student registration/login requires Supabase MCP tool activation
- Profile updates require database connectivity
- Class Enrollment and Recordings sections are placeholder

## Required Backend Services
- User registration and authentication (Supabase Auth)
- Profile data storage and management (user_profiles table)
- Session management (Supabase Auth)
- Role-based access control (student vs admin)

## Development Notes
- Mobile-responsive design implemented
- Ready for Supabase integration
- Clean separation between auth and dashboard sections
- Extensible navigation system for additional features